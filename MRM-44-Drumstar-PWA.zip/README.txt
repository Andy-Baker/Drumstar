MRM-44 · Drumstar PWA
====================

Deployment:
1. Upload all files/folders to a HTTPS host, e.g. GitHub Pages.
2. Open the deployed index.html on Android Chrome.
3. Use "Installieren" or the browser menu -> Install app.
4. The installed app runs in standalone/fullscreen mode.

Important:
- Microphone recording requires HTTPS (or localhost) and user permission.
- Patterns and samples are stored locally in IndexedDB for this browser/origin.
- The Service Worker caches the app shell for offline startup after the first visit.
